<?php

namespace App\Http\Controllers;

use App\Article;
use App\Dynamic;
use App\Notice;
use App\Volunteer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class IndexController extends Controller
{

    // TODO 首页：捐赠，点赞，签到，最新动态， 个人中心：评分（前后）,二维码
    /**
     * 首页
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index(Request $request)
    {
        $time = date("Y-m-d ") . $this->getWeek();
        return view('web/index', ['time' => $time]);
    }

    /**
     *z z志愿活动 列表详情
     * @param Request $request
     * @param null $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function volunteer(Request $request, $id = null)
    {
        if ($id) {
            $detail = Volunteer::findorfail($id);
            return view('web/detail/volunteer', ['detail' => $detail]);
        }
        $article = DB::table('volunteer')
            ->orderBy('created_at', 'desc')
            ->paginate(10);
        $class = [
            1 => 'layui-bg-green',
            2 => 'layui-bg-blue',
            3 => '',
        ];
        $text = [
            1 => '报名中',
            2 => '活动中',
            3 => '已结束',
        ];
        return view('web/volunteer', ['page' => $article, 'class' => $class, 'text' => $text]);
    }

    public function dynamic(Request $request, $id = null)
    {
        if ($id) {
            $detail = Dynamic::findorfail($id);
            return view('web/detail/dynamic', ['detail' => $detail]);
        }
        $article = DB::table('dynamic')
            ->orderBy('created_at', 'desc')
            ->paginate(10);
        return view('web/dynamic', ['page' => $article]);
    }

    /**
     * 通知公告
     * @param Request $request
     * @param null $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function notice(Request $request, $id = null)
    {
        if ($id) {
            $detail = Notice::findorfail($id);
            return view('web/detail/notice', ['detail' => $detail]);
        }
        $article = DB::table('notice')
            ->orderBy('created_at', 'desc')
            ->paginate(10);
        return view('web/notice', ['page' => $article]);
    }

    /**
     * 文章 文化
     * @param Request $request
     * @param null $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function article(Request $request, $id = null)
    {
        // 1文化大礼堂，2产品大讲堂，3我要学政策
        if ($id) {
            $detail = Article::findorfail($id);
            return view('web/detail/article', ['detail' => $detail]);
        }
        $article = DB::table('article')
            ->where('type', 1)
            ->orderBy('created_at', 'desc')
            ->paginate(10);
        return view('web/article', ['page' => $article]);
    }

    /**、
     * 文章 产品
     * @param Request $request
     * @param null $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function product(Request $request, $id = null)
    {
        if ($id) {
            $detail = Article::findorfail($id);
            return view('web/detail/article', ['detail' => $detail]);
        }
        $article = DB::table('article')
            ->where('type', 2)
            ->orderBy('created_at', 'desc')
            ->paginate(10);
        return view('web/product', ['page' => $article]);
    }

    /**
     * 文章 政策
     * @param Request $request
     * @param null $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function policy(Request $request, $id = null)
    {
        if ($id) {
            $detail = Article::findorfail($id);
            return view('web/detail/article', ['detail' => $detail]);
        }
        $article = DB::table('article')
            ->where('type', 3)
            ->orderBy('created_at', 'desc')
            ->paginate(10);
        return view('web/policy', ['page' => $article]);
    }

    /**
     * 方法 获取日期，星期
     * @return string
     */
    function getWeek()
    {
        $week_array = array("日", "一", "二", "三", "四", "五", "六");
        return "星期" . $week_array[date("w")];
    }

}
